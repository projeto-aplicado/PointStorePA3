package br.com.pointstore;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.TextView;
import android.widget.Toast;

import br.com.pointstore.Adapter.UsuarioLogin;
import br.com.pointstore.DAO.DataAccessObject;
import br.com.pointstore.model.Usuario;
import br.com.pointstore.util.Login;
import rest.LoginService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

public class CarregarPerfil extends AppCompatActivity {
    TextView TextLogin;
    TextView TextEmail;
    TextView TextSobrenome;
    TextView TextSenha;
    private LoginService mLoginService;
    final  DataAccessObject dataAccessObject = new DataAccessObject(this);

    UsuarioLogin usuarioLogin = new UsuarioLogin();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carregar_perfil);

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://10.0.3.2").
                addConverterFactory(JacksonConverterFactory.create()).build();

        mLoginService = retrofit.create(LoginService.class);


        TextLogin = (TextView) findViewById(R.id.ed_login);
        TextEmail= (TextView) findViewById(R.id.ed_email);
        TextSobrenome = (TextView) findViewById(R.id.ed_sobrenome);
        TextSenha  = (TextView) findViewById(R.id.ed_senha);

        Button btCarregarDados = (Button) findViewById(R.id.bt_carregar_dados);

        Button btLogOff = (Button) findViewById(R.id.bt_logoff);

        usuarioLogin = dataAccessObject.procurarLoginSalvoSQLlite();

        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, "Login :"+usuarioLogin.getLogin()+" Senha : "+usuarioLogin.getSenha(), Toast.LENGTH_SHORT);
        toast.show();

        Call<Usuario> userLoginCall = mLoginService.loginUser(usuarioLogin);

        btCarregarDados.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //usuarioLogin = dataAccessObject.procurarLoginSalvoSQLlite();
                TextLogin.setText(usuarioLogin.getLogin());

                TextSenha.setText(usuarioLogin.getSenha());


               Call<Usuario> userLoginCall = mLoginService.loginUser(usuarioLogin);


                userLoginCall.enqueue(new Callback<Usuario>() {

                    @Override
                    public void onResponse(Call<Usuario> call, Response<Usuario> response) {

                        Usuario user = response.body();

                         TextLogin.setText(user.getLogin());
                         TextEmail.setText(user.getEmail());
                         TextSobrenome.setText(user.getSobrenome());
                         TextSenha.setText(user.getSenha());
                        Context context = getApplicationContext();

                        Toast toast = Toast.makeText(context, " Nome : " +user.getNome()+" sobrenome : "+user.getSobrenome()
                                +" email : " +user.getEmail()+" login : "+user.getLogin() +" senha : "+user.getSenha(), Toast.LENGTH_SHORT);
                        toast.show();

                    }

                    @Override
                    public void onFailure(Call<Usuario> call, Throwable t) {}


                });


            }
        });

        btLogOff.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                dataAccessObject.deletar();
                Intent proximapagina = new Intent(CarregarPerfil.this, Login.class);
                startActivity(proximapagina);
            }
        });




    }


    }