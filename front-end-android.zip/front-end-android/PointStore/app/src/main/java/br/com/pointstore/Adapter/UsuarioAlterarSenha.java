package br.com.pointstore.Adapter;

/**
 * Created by Arley on 30/11/2017.
 */

public class UsuarioAlterarSenha {

    private String email;
    private String senha;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
